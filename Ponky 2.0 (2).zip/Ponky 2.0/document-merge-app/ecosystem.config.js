module.exports = {
  apps: [{
    name: "document-merge-app",
    script: "./server.js",
    instances: 1,
    cwd: "D:/PROYECTOS VISUAL CODE/Ponky 2.0/document-merge-app",
    watch: false,
    env: {
      NODE_ENV: "development",
      PORT: 3000,
      HOST: "10.10.90.14"
    },
    env_production: {
      NODE_ENV: "production",
      PORT: 3000,
      HOST: "10.10.90.14"
    }
  }]
}
