import pandas as pd
import os
from jinja2 import Environment, FileSystemLoader
from datetime import datetime

# --- CONFIGURACIÓN ---
CSV_FILE = 'products_export_actualizado (11).csv'  # Nuevo archivo más reciente
TEMPLATE_FILE = 'template.html'
OUTPUT_DIR = 'output_docs'

# --- PREPARACIÓN ---
os.makedirs(OUTPUT_DIR, exist_ok=True)

# --- CARGAR PLANTILLA ---
env = Environment(loader=FileSystemLoader('./public'))
template = env.get_template(TEMPLATE_FILE)

# --- FUNCIONES AUXILIARES ---
def clean_field(value):
    if pd.isna(value):
        return ''
    return str(value).replace('\n', ' ').replace('\r', '').strip()

# --- CARGA Y LIMPIEZA DE DATOS ---
print("🔄 Cargando archivo CSV...")
df = pd.read_csv(CSV_FILE, engine='python', on_bad_lines='skip')
df.fillna('', inplace=True)

print("🧼 Limpiando datos...")
for col in df.columns:
    df[col] = df[col].apply(clean_field)

# --- GENERAR UN DOCUMENTO POR CADA PRODUCTO ---
print("📄 Generando documentos HTML...")
for i, row in df.iterrows():
    data = row.to_dict()
    data['date'] = datetime.today().strftime('%d-%m-%Y')
    filename = f"Producto_{data.get('Handle', 'sin_nombre')}_{i}.html"
    filename = filename.replace('/', '_')  # evitar errores por nombres inválidos
    html_output = template.render(data)

    with open(os.path.join(OUTPUT_DIR, filename), 'w', encoding='utf-8') as f:
        f.write(html_output)

print(f"✅ Se generaron {len(df)} archivos HTML en la carpeta '{OUTPUT_DIR}'")