// This file contains the JavaScript code that handles the logic for uploading the three documents, merging their content, and generating the final output based on the template. It also includes functionality for previewing the final document before downloading.
// Requiere SheetJS: <script src="https://cdn.sheetjs.com/xlsx-latest/package/dist/xlsx.full.min.js"></script>

document.addEventListener('DOMContentLoaded', () => {
    const fileInputs = [
        document.getElementById('doc1'),
        document.getElementById('doc2'),
        document.getElementById('doc3')
    ];
    const previewButton = document.getElementById('preview');
    const downloadButton = document.getElementById('download-btn');
    const outputContainer = document.getElementById('preview');
    const previewContainer = document.getElementById('preview-container');

    let dataFiles = [null, null, null];
    let notFoundSkusDownloaded = false;  // Add this at the top with other variables
    let isProcessing = false;
    let downloadInProgress = false;
    let hasDownloadedSkus = false; // Variable para controlar la descarga

    // Objeto para mantener el estado de los archivos
    const fileStates = JSON.parse(localStorage.getItem('fileStates')) || {
        doc1: { status: 'pending', filename: null },
        doc2: { status: 'pending', filename: null },
        doc3: { status: 'pending', filename: null }
    };

    // Estado de archivos
    const filesState = {
        files: JSON.parse(localStorage.getItem('uploadedFiles')) || {},
        
        saveState(fileId, data, fileName) {
            this.files[fileId] = { data, fileName };
            localStorage.setItem('uploadedFiles', JSON.stringify(this.files));
            this.updateUI(fileId, fileName);
        },

        removeState(fileId) {
            delete this.files[fileId];
            localStorage.setItem('uploadedFiles', JSON.stringify(this.files));
            this.updateUI(fileId, null);
        },

        updateUI(fileId, fileName) {
            const status = document.getElementById(`status-${fileId}`);
            const fileIcon = document.querySelector(`label[for="${fileId}"] .file-icon`);
            
            if (fileName) {
                status.className = 'file-status success';
                status.querySelector('.file-status-icon').textContent = '✅';
                status.querySelector('.file-status-text').textContent = `${fileName}`;
                fileIcon.textContent = '📄';
            } else {
                status.className = 'file-status pending';
                status.querySelector('.file-status-icon').textContent = '⚪';
                status.querySelector('.file-status-text').textContent = 'Pendiente';
                fileIcon.textContent = '📊';
            }
        },

        restoreStates() {
            Object.entries(this.files).forEach(([fileId, fileInfo]) => {
                this.updateUI(fileId, fileInfo.fileName);
                const index = parseInt(fileId.replace('doc', '')) - 1;
                dataFiles[index] = fileInfo.data;
            });
        }
    };

    // Restaurar estados al cargar
    filesState.restoreStates();

    // Función para mostrar notificaciones toast
    function showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        document.body.appendChild(toast);
        
        // Remover después de 3 segundos
        setTimeout(() => {
            toast.remove();
        }, 3000);
    }

    // Función para actualizar el estado visual
    function updateFileStatus(fileId, status, filename = null) {
        const fileStatus = document.getElementById(`status-${fileId}`);
        if (!fileStatus) return;

        const statusIcon = fileStatus.querySelector('.file-status-icon');
        const statusText = fileStatus.querySelector('.file-status-text');

        fileStates[fileId] = { status, filename };
        localStorage.setItem('fileStates', JSON.stringify(fileStates));

        switch (status) {
            case 'success':
                fileStatus.className = 'file-status success';
                statusIcon.textContent = '✅';
                statusText.textContent = `Archivo cargado: ${filename}`;
                break;
            case 'error':
                fileStatus.className = 'file-status error';
                statusIcon.textContent = '❌';
                statusText.textContent = 'Error al procesar';
                break;
            default:
                fileStatus.className = 'file-status pending';
                statusIcon.textContent = '⚪';
                statusText.textContent = 'Pendiente';
        }
    }

    // Función para restaurar estados visuales
    function restoreFileStates() {
        for (let i = 0; i < 3; i++) {
            const fileId = `doc${i + 1}`;
            const storedData = localStorage.getItem(fileId);
            
            if (storedData) {
                const status = document.getElementById(`status-${fileId}`);
                const fileLabel = document.querySelector(`label[for="${fileId}"]`);
                const fileName = document.querySelector(`label[for="${fileId}"] .file-name`);
                
                status.className = 'file-status success';
                status.querySelector('.file-status-icon').textContent = '✅';
                status.querySelector('.file-status-text').textContent = 'Archivo cargado';
                fileLabel.style.backgroundColor = '#e8f5e9';
                
                // Intentar obtener el nombre del archivo del localStorage
                try {
                    const parsedData = JSON.parse(storedData);
                    if (parsedData.fileName) {
                        fileName.textContent = parsedData.fileName;
                    }
                } catch (e) {
                    console.warn('No se pudo recuperar el nombre del archivo');
                }
            }
        }
    }

    // Leer archivos y guardar en localStorage
    function handleFile(index, file) {
        const fileId = `doc${index + 1}`;
        updateFileStatus(fileId, 'pending');

        const reader = new FileReader();
        reader.onerror = (e) => {
            console.error(`Error leyendo archivo ${index+1}:`, e);
            updateFileStatus(fileId, 'error');
            showToast(`❌ Error al cargar ${file.name}`, 'error');
        };

        reader.onload = (e) => {
            try {
                let data;
                if (index === 0) {
                    // XLSX con codificación UTF-8
                    const workbook = XLSX.read(e.target.result, { 
                        type: 'binary',
                        codepage: 65001 // UTF-8
                    });
                    const sheetName = workbook.SheetNames[0];
                    data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { 
                        header: 1,
                        raw: false,
                        defval: ''
                    });
                } else {
                    // CSV con codificación UTF-8
                    const csvData = new TextDecoder('utf-8').decode(e.target.result);
                    data = XLSX.read(csvData, {
                        type: 'string',
                        codepage: 65001
                    }).Sheets.Sheet1;
                    data = XLSX.utils.sheet_to_json(data, { 
                        header: 1,
                        raw: false,
                        defval: ''
                    });
                }
                dataFiles[index] = data;
                localStorage.setItem(`doc${index+1}`, JSON.stringify({
                    data: data,
                    fileName: file.name
                }));
                
                updateFileStatus(`doc${index+1}`, 'success', file.name);
                showToast(`✅ ${file.name} cargado correctamente`);
            } catch (err) {
                console.error(`Error procesando archivo ${index+1}:`, err);
                updateFileStatus(fileId, 'error');
                filesState.removeState(fileId);
                showToast(`❌ Error al procesar ${file.name}`, 'error');
            }
        };
        if (index === 0) {
            reader.readAsBinaryString(file);
        } else {
            reader.readAsArrayBuffer(file);
        }
    }

    // Cargar desde localStorage si existe
    for (let i = 0; i < 3; i++) {
        const stored = localStorage.getItem(`doc${i+1}`);
        if (stored) {
            try {
                dataFiles[i] = JSON.parse(stored);
                console.log(`Archivo ${i+1} cargado desde localStorage`, dataFiles[i]);
            } catch (err) {
                console.error(`Error leyendo localStorage doc${i+1}:`, err);
            }
        }
    }

    // Cambiar tipos de archivos aceptados
    fileInputs[0].setAttribute('accept', '.xlsx');
    fileInputs[1].setAttribute('accept', '.csv');
    fileInputs[2].setAttribute('accept', '.csv');

    fileInputs.forEach((input, idx) => {
        input.addEventListener('change', (event) => {
            const file = event.target.files[0];
            if (!file) return;
            if (idx === 0 && !file.name.endsWith('.xlsx')) {
                console.error('El primer archivo debe ser XLSX');
                return;
            }
            if (idx > 0 && !file.name.endsWith('.csv')) {
                console.error('El archivo debe ser CSV');
                return;
            }
            handleFile(idx, file);
        });
    });

    // Cruce de datos por encabezados
    function mergeByHeaders(data1, data2, data3) {
        if (!data1 || !data2 || !data3) {
            console.error('Faltan archivos para el cruce');
            return '';
        }
        // Suponiendo que la primera fila es encabezado
        const headers1 = data1[0];
        const headers2 = data2[0];
        const headers3 = data3[0];

        // Mapear datos por encabezado
        const rows1 = data1.slice(1);
        const rows2 = data2.slice(1);
        const rows3 = data3.slice(1);

        // Ejemplo: cruzar por el primer encabezado común
        const key = headers1[0];
        const idx2 = headers2.indexOf(key);
        const idx3 = headers3.indexOf(key);

        if (idx2 === -1 || idx3 === -1) {
            console.error('No se encontró un encabezado común para el cruce');
            return 'No se puede cruzar por encabezado común.';
        }

        // Crear mapas para acceso rápido
        const map2 = Object.fromEntries(rows2.map(r => [r[idx2], r]));
        const map3 = Object.fromEntries(rows3.map(r => [r[idx3], r]));

        // Unir datos
        const merged = rows1.map(r1 => {
            const keyValue = r1[0];
            const row2 = map2[keyValue] || [];
            const row3 = map3[keyValue] || [];
            return [
                ...headers1.map((_, i) => r1[i] ?? ''),
                ...headers2.map((h, i) => i !== idx2 ? (row2[i] ?? '') : null).filter(v => v !== null),
                ...headers3.map((h, i) => i !== idx3 ? (row3[i] ?? '') : null).filter(v => v !== null)
            ];
        });

        // Encabezados finales
        const finalHeaders = [
            ...headers1,
            ...headers2.filter((_, i) => i !== idx2),
            ...headers3.filter((_, i) => i !== idx3)
        ];

        // Convertir a tabla HTML
        let html = '<table><thead><tr>' + finalHeaders.map(h => `<th>${h}</th>`).join('') + '</tr></thead><tbody>';
        merged.forEach(row => {
            html += '<tr>' + row.map(cell => `<td>${cell ?? ''}</td>`).join('') + '</tr>';
        });
        html += '</tbody></table>';
        return html;
    }

    function clean(value) {
        return (value ?? '').toString().trim().toUpperCase();
    }

    // Buscar encabezado ignorando mayúsculas/minúsculas y espacios
    function findHeader(headers, target) {
        if (!headers || !Array.isArray(headers)) {
            console.warn('Headers inválidos:', headers);
            return -1;
        }
        const cleanTarget = target.trim().toUpperCase();
        return headers.findIndex(h => 
            (h ?? '').toString().trim().toUpperCase() === cleanTarget
        );
    }

    // Sugerir encabezados similares
    function suggestHeader(headers, target) {
        const cleanTarget = target.trim().toUpperCase();
        return headers.filter(h => (h ?? '').toString().trim().toUpperCase().includes(cleanTarget.slice(0, 4)));
    }

    // Cruce personalizado según instrucciones, limpiando datos antes de comparar
    function customMerge(data1, data2, data3) {
        if (!data1 || !data2 || !data3) {
            console.error('Faltan archivos para el cruce');
            return '';
        }

        // Encabezados
        const headers1 = data1[0];
        const headers2 = data2[0];
        const headers3 = data3[0];

        // Mostrar cómo se están leyendo los encabezados
        console.log('Encabezados archivo 1:', headers1);
        console.log('Encabezados archivo 2:', headers2);
        console.log('Encabezados archivo 3:', headers3);

        // Validar y buscar índices de encabezados requeridos
        const idxCodigo = findHeader(headers1, 'CODIGO');
        const idxVariantSKU = findHeader(headers2, 'Variant SKU');
        const idxSku3 = findHeader(headers3, 'Variant SKU');
        const idxCantidad = findHeader(headers1, 'CANTIDAD');
        const idxPrecio = findHeader(headers1, 'PRECIO_VENTA');
        const idxQty3 = findHeader(headers3, 'Variant Inventory Qty');
        const idxPrice3 = findHeader(headers3, 'Variant Price');

        // Validar existencia de encabezados
        const required = [
            {name: 'CODIGO', idx: idxCodigo, headers: headers1},
            {name: 'CANTIDAD', idx: idxCantidad, headers: headers1},
            {name: 'PRECIO_VVENTA', idx: idxPrecio, headers: headers1},
            {name: 'Variant SKU (archivo 2)', idx: idxVariantSKU, headers: headers2},
            {name: 'Variant SKU (archivo 3)', idx: idxSku3, headers: headers3},
            {name: 'Variant Inventory Qty', idx: idxQty3, headers: headers3},
            {name: 'Variant Price', idx: idxPrice3, headers: headers3}
        ];
        let faltantes = required.filter(r => r.idx === -1);
        if (faltantes.length > 0) {
            faltantes.forEach(f => {
                console.error(`No se encontró el encabezado "${f.name}". Encabezados disponibles:`, f.headers);
                const sugeridos = suggestHeader(f.headers, f.name);
                if (sugeridos.length > 0) {
                    console.warn(`¿Quizás quisiste decir?:`, sugeridos);
                }
            });
            return 'Faltan encabezados requeridos. Revisa la consola para detalles.';
        }

        // Crear mapa de archivo 1 por CODIGO (limpio)
        const map1 = {};
        for (let i = 1; i < data1.length; i++) {
            const row = data1[i];
            map1[clean(row[idxCodigo])] = row;
        }

        // Crear mapa de archivo 2 por Variant SKU (limpio)
        const map2 = {};
        for (let i = 1; i < data2.length; i++) {
            const row = data2[i];
            map2[clean(row[idxVariantSKU])] = row;
        }

        // Determinar encabezados comunes entre archivo 2 y 3
        const commonHeaders = headers2.filter(h => headers3.includes(h));

        // Construir nuevas filas para archivo 3
        const newData3 = [headers3];
        for (let i = 1; i < data3.length; i++) {
            const row3 = data3[i].slice(); // Copia de la fila
            const sku = clean(row3[idxSku3]);
            const row2 = map2[sku];
            const row1 = map1[clean(row2 ? row2[idxVariantSKU] : '')];

            if (row2 && row1) {
                // Pegar datos de encabezados comunes de archivo 2 a archivo 3
                commonHeaders.forEach(h => {
                    const idx2 = headers2.indexOf(h);
                    const idx3 = headers3.indexOf(h);
                    if (idx2 !== -1 && idx3 !== -1) {
                        row3[idx3] = row2[idx2];
                    }
                });
                // Pegar cantidad y precio desde archivo 1
                if (idxQty3 !== -1) row3[idxQty3] = row1[idxCantidad];
                if (idxPrice3 !== -1) row3[idxPrice3] = row1[idxPrecio];
            }
            newData3.push(row3);
        }

        // Convertir a tabla HTML para vista previa (tabla con scroll horizontal)
        let html = `
        <div class="scroll-table-wrapper">
            <table>
                <thead><tr>${headers3.map(h => `<th>${h}</th>`).join('')}</tr></thead>
                <tbody>
        `;
        for (let i = 1; i < newData3.length; i++) {
            html += '<tr>' + newData3[i].map(cell => `<td>${cell ?? ''}</td>`).join('') + '</tr>';
        }
        html += `
                </tbody>
            </table>
        </div>
        `;
        return html;
    }

    // Función para detectar el SKU válido
    function getValidSKU(row, headers) {
        const idxSKU = findHeader(headers, 'Variant SKU');
        const idxBarcode = findHeader(headers, 'Variant Barcode');
        
        const sku = clean(row[idxSKU]);
        const barcode = clean(row[idxBarcode]);
        
        return sku || barcode || '';
    }

    function formatPrecision(number) {
        if (!number) return '0.00';
        return Number(number).toFixed(2);
    }

    function formatDisplay(number) {
        if (!number) return '-';
        return Number(number).toLocaleString('es-CO', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    // Función para calcular precio con descuento según Tipología
    function calcularPrecios(precioBase, tipologia) {
        try {
            const precio = limpiarPrecio(precioBase);
            if (precio <= 0) {
                console.warn('⚠️ Precio base inválido:', precioBase);
                return { price: '0.00', comparePrice: '' };
            }

            const tipo = clean(tipologia);
            switch (tipo) {
                case '3. TIPO 3':
                    return {
                        price: (precio * 0.70).toFixed(2),
                        comparePrice: precio.toFixed(2)
                    };
                case '4. TIPO 4':
                    return {
                        price: (precio * 0.50).toFixed(2),
                        comparePrice: precio.toFixed(2)
                    };
                default:
                    return {
                        price: precio.toFixed(2),
                        comparePrice: ''
                    };
            }
        } catch (error) {
            console.error('Error en cálculo de precios:', error);
            return { price: '0.00', comparePrice: '' };
        }
    }

    // Función para limpiar el campo PRECIO_VENTA
    function limpiarPrecio(precio) {
        try {
            if (!precio) return 0;
            // Eliminar símbolo de moneda, comas, espacios y caracteres no numéricos
            const limpio = precio.toString()
                .replace(/[$,\s]/g, '')  // eliminar $, comas y espacios
                .replace(/[^\d.-]/g, ''); // mantener solo números, punto y signo negativo
            
            const numero = parseFloat(limpio);
            if (isNaN(numero)) {
                console.warn(`⚠️ Precio base inválido: ${precio}`);
                return 0;
            }
            return numero;
        } catch (error) {
            console.warn(`⚠️ Error limpiando precio: ${precio}`, error);
            return 0;
        }
    }

    function calcularVariantPrice(precioBase, tipologia) {
        try {
            const precio = parseFloat(precioBase);
            if (isNaN(precio)) return 0;

            switch(clean(tipologia)) {
                case '3. TIPO 3':
                    return Number((precio * 0.70).toFixed(2));
                case '4. TIPO 4':
                    return Number((precio * 0.50).toFixed(2));
                default:
                    return Number(precio.toFixed(2));
            }
        } catch (error) {
            console.error('Error calculando Variant Price:', error);
            return 0;
        }
    }

    function calcularCompareAtPrice(precioBase, tipologia) {
        try {
            const precio = parseFloat(precioBase);
            if (isNaN(precio)) return '';
            
            const tipo = clean(tipologia);
            if (['3. TIPO 3', '4. TIPO 4'].includes(tipo)) {
                return precio.toFixed(2);
            }
            return '';
        } catch {
            return '';
        }
    }

    // Agregar esta función al inicio, junto con las otras funciones auxiliares
    function formatPrice(price) {
        if (price === null || price === undefined || price === '') return '-';
        try {
            const numero = parseFloat(price);
            if (isNaN(numero)) return '-';
            return numero.toLocaleString('es-CO', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        } catch (error) {
            console.warn('Error formateando precio:', price, error);
            return '-';
        }
    }

    // Actualizar función de generación de CSV
    function generateTemplateCSV(data1, data2) {
        const headers = data2[0];
        const rows = [headers];

        // Encontrar índices
        const idxCodigo = findHeader(data1[0], 'CODIGO');
        const idxPrecio = findHeader(data1[0], 'PRECIO_VENTA');
        const idxCantidad = findHeader(data1[0], 'CANTIDAD');
        const idxTipologia = findHeader(data1[0], 'Tipologia');
        
        const idxSku = findHeader(headers, 'Variant SKU');
        const idxBarcode = findHeader(headers, 'Variant Barcode');
        const idxPrice = findHeader(headers, 'Variant Price');
        const idxQty = findHeader(headers, 'Variant Inventory Qty');

        // Crear mapa de productos con sus tipologías
        const productMap = {};
        for (let i = 1; i < data1.length; i++) {
            const row = data1[i];
            const codigo = clean(row[idxCodigo]);
            if (codigo) {
                const precioBase = row[idxPrecio];
                const tipologia = row[idxTipologia];
                productMap[codigo] = {
                    precio: calcularPrecios(precioBase, tipologia).price,
                    cantidad: row[idxCantidad],
                    tipologia: tipologia
                };
            }
        }

        // Actualizar renderizado de tabla para mostrar descuentos
        let totalProductos = 0;
        let productosConDescuento = 0;

        // Procesar cada fila del export
        for (let i = 1; i < data2.length; i++) {
            const row = [...data2[i]];
            let sku = clean(row[idxSku]);
            if (!sku && idxBarcode !== -1) {
                sku = clean(row[idxBarcode]);
            }

            if (sku && productMap[sku]) {
                totalProductos++;
                if (productMap[sku].precio !== parseFloat(row[idxPrice])) {
                    productosConDescuento++;
                }
                row[idxPrice] = productMap[sku].precio;
                row[idxQty] = productMap[sku].cantidad;
            }
            rows.push(row);
        }

        console.log(`Total productos procesados: ${totalProductos}`);
        console.log(`Productos con descuento: ${productosConDescuento}`);

        return rows.map(row => 
            row.map(cell => `"${(cell || '').toString().replace(/"/g, '""')}"`)
            .join(',')
        ).join('\n');
    }

    // Funciones de formato de precios
    function formatNumber(value) {
        if (!value || isNaN(value)) return '0.00';
        return Number(value).toFixed(2);
    }

    function formatDisplayPrice(value) {
        if (!value || isNaN(value)) return '-';
        return `$${Number(value).toLocaleString('es-CO', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })}`;
    }

    // Validar encabezados requeridos
    function validateHeaders(headers, requiredHeaders) {
        const missingHeaders = requiredHeaders.filter(header => findHeader(headers, header) === -1);
        if (missingHeaders.length > 0) {
            console.error('Faltan los siguientes encabezados:', missingHeaders);
            return false;
        }
        return true;
    }

    // Actualizar función de renderizado de tabla para mostrar descuentos
    function renderCrossTable(data1, data2) {
        if (!data1 || !data2) return '<p>No se encontraron datos para el cruce.</p>';

        console.log('Renderizando tabla con datos:', { data1: data1.length, data2: data2.length });

        const headers1 = data1[0];
        const headers2 = data2[0];

        // Validar encabezados requeridos
        const requiredHeaders1 = ['CODIGO', 'PRECIO_VENTA', 'CANTIDAD', 'Tipologia'];
        const requiredHeaders2 = ['Variant SKU', 'Variant Barcode'];
        if (!validateHeaders(headers1, requiredHeaders1) || !validateHeaders(headers2, requiredHeaders2)) {
            return '<p>Error: Faltan encabezados requeridos. Revisa la consola para más detalles.</p>';
        }

        // Detectar índices
        const indices = {
            codigo: findHeader(headers1, 'CODIGO'),
            precio: findHeader(headers1, 'PRECIO_VENTA'),
            cantidad: findHeader(headers1, 'CANTIDAD'),
            tipologia: findHeader(headers1, 'Tipologia'),
            sku: findHeader(headers2, 'Variant SKU'),
            barcode: findHeader(headers2, 'Variant Barcode'),
            price: findHeader(headers2, 'Variant Price'),
            comparePrice: findHeader(headers2, 'Variant Compare At Price')
        };

        // Procesar productos
        const productos = [];
        for (let i = 1; i < data2.length; i++) {
            const row2 = data2[i];
            let sku = clean(row2[indices.sku]);
            if (!sku && indices.barcode !== -1) {
                sku = clean(row2[indices.barcode]);
            }

            // Buscar coincidencia en data1
            const match = data1.slice(1).find(row1 => clean(row1[indices.codigo]) === sku);

            if (match) {
                const precioBase = match[indices.precio];
                const tipologia = match[indices.tipologia];
                const precios = calcularPrecios(precioBase, tipologia);

                productos.push({
                    codigo: match[indices.codigo],
                    precioVenta: limpiarPrecio(precioBase),
                    tipologia: tipologia || 'Sin tipo',
                    variantPrice: precios.price,
                    variantComparePrice: precios.comparePrice || '-',
                    sku,
                    stock: match[indices.cantidad]
                });
            }
        }

        // Mostrar primeras filas en consola
        console.log('📊 Primeras filas después del merge:');
        productos.slice(0, 5).forEach(p => {
            console.log(`
    CODIGO: ${p.codigo}
    PRECIO_VENTA: ${p.precioVenta}
    Tipologia: ${p.tipologia}
    Variant Price: ${p.variantPrice}
    Variant Compare At Price: ${p.variantComparePrice}
    ${'-'.repeat(50)}`);
        });

        // Generar HTML para la tabla
        if (!productos.length) return '<p>No se encontraron coincidencias.</p>';

        return `
            <div class="scroll-table-container">
                <div class="matches-count">
                    Productos encontrados: ${productos.length}
                </div>
                <div class="scroll-table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>CODIGO</th>
                                <th>PRECIO_VENTA</th>
                                <th>Tipologia</th>
                                <th>Variant Price</th>
                                <th>Variant Compare At Price</th>
                                <th>SKU</th>
                                <th>Stock</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${productos.map(p => `
                                <tr>
                                    <td>${p.codigo}</td>
                                    <td>${p.precioVenta}</td>
                                    <td>${p.tipologia}</td>
                                    <td>${p.variantPrice}</td>
                                    <td>${p.variantComparePrice}</td>
                                    <td>${p.sku}</td>
                                    <td>${p.stock || 0}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    function renderFilteredTable(productos, filterType) {
        let filteredProducts = productos;

        if (filterType === 'conDescuento') {
            filteredProducts = productos.filter(p => p.variantComparePrice !== '-');
        } else if (filterType === 'sinDescuento') {
            filteredProducts = productos.filter(p => p.variantComparePrice === '-');
        }

        return `
            <div class="scroll-table-container">
                <div class="matches-count">
                    Productos encontrados: ${filteredProducts.length}
                </div>
                <div class="scroll-table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>CODIGO</th>
                                <th>PRECIO_VENTA</th>
                                <th>Tipologia</th>
                                <th>Variant Price</th>
                                <th>Variant Compare At Price</th>
                                <th>SKU</th>
                                <th>Stock</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${filteredProducts.map(p => `
                                <tr>
                                    <td>${p.codigo}</td>
                                    <td>${p.precioVenta}</td>
                                    <td>${p.tipologia}</td>
                                    <td>${p.variantPrice}</td>
                                    <td>${p.variantComparePrice}</td>
                                    <td>${p.sku}</td>
                                    <td>${p.stock || 0}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    // Funciones para SKUs no encontrados
    function renderNoEncontradosTable(data1, data2) {
        const indices = {
            codigo: findHeader(data1[0], 'CODIGO'),
            descripcion: findHeader(data1[0], 'DESCRIPCION'),
            precio: findHeader(data1[0], 'PRECIO_VENTA'),
            cantidad: findHeader(data1[0], 'CANTIDAD'),
            variantSku: findHeader(data2[0], 'Variant SKU'),
            barcode: findHeader(data2[0], 'Variant Barcode')
        };

        // Recolectar SKUs del export
        const skusExport = new Set(
            data2.slice(1).map(row => {
                const sku = clean(row[indices.variantSku]);
                const barcode = clean(row[indices.barcode]);
                return sku || barcode;
            }).filter(Boolean)
        );

        // Encontrar productos no encontrados
        const productosNoEncontrados = data1.slice(1)
            .filter(row => {
                const sku = clean(row[indices.codigo]);
                return sku && !skusExport.has(sku);
            })
            .map(row => ({
                sku: row[indices.codigo],
                nombre: row[indices.descripcion] || 'Sin descripción',
                precio: formatDisplayPrice(row[indices.precio]),
                cantidad: row[indices.cantidad] || '0',
                motivo: 'No existe en Shopify'
            }));

        // Generar HTML de la tabla
        return `
            <div class="scroll-table-container">
                <div class="matches-count">
                    <strong>SKUs no encontrados: ${productosNoEncontrados.length}</strong>
                </div>
                <div class="scroll-table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>SKU</th>
                                <th>NOMBRE DEL PRODUCTO</th>
                                <th>PRECIO VENTA</th>
                                <th>CANTIDAD</th>
                                <th>MOTIVO</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${productosNoEncontrados.map(p => `
                                <tr>
                                    <td>${p.sku}</td>
                                    <td>${p.nombre}</td>
                                    <td>${p.precio}</td>
                                    <td>${p.cantidad}</td>
                                    <td>${p.motivo}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    // Crear contenedor para botones de reporte
    const reportButtonsContainer = document.createElement('div');
    reportButtonsContainer.style.cssText = `
        display: flex;
        justify-content: center;
        gap: 10px;
        margin: 20px 0;
        padding: 10px;
        background-color: #f5f5f5;
        border-radius: 5px;
    `;

    // Botón para descargar reporte
    const downloadReportButton = document.createElement('button');
    downloadReportButton.textContent = '📥 Descargar SKUs No Encontrados';
    downloadReportButton.style.cssText = `
        padding: 10px 20px;
        background-color: #FF9800;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
        flex: 1;
        max-width: 300px;
    `;

    // Botón para mostrar en pantalla
    const showReportButton = document.createElement('button');
    showReportButton.textContent = '👁️ Ver SKUs No Encontrados';
    showReportButton.style.cssText = `
        padding: 10px 20px;
        background-color: #2196F3;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
        flex: 1;
        max-width: 300px;
    `;

    // Agregar eventos a los botones
    downloadReportButton.addEventListener('click', () => {
        if (!dataFiles[0] || !dataFiles[1]) {
            alert('❌ Debes cargar los archivos necesarios primero');
            return;
        }
        const count = generarReporteSKUsNoEncontrados(dataFiles[0], dataFiles[1]);
        alert(`✅ Reporte descargado con ${count} SKUs no encontrados`);
    });

    showReportButton.addEventListener('click', () => {
        if (!dataFiles[0] || !dataFiles[1]) {
            alert('❌ Debes cargar los archivos necesarios primero');
            return;
        }
        document.getElementById('cross-table').innerHTML = renderNoEncontradosTable(dataFiles[0], dataFiles[1]);
    });

    // Agregar botones al contenedor
    reportButtonsContainer.appendChild(downloadReportButton);
    reportButtonsContainer.appendChild(showReportButton);

    // Insertar contenedor después del formulario
    document.getElementById('upload-form').after(reportButtonsContainer);

    // Botón de generar vista previa
    document.getElementById('upload-form').addEventListener('submit', (e) => {
        e.preventDefault();
        if (!dataFiles[0] || !dataFiles[1] || !dataFiles[2]) {
            console.error('Debes cargar los tres archivos antes de generar el documento.');
            alert('Debes cargar los tres archivos antes de generar el documento.');
            return;
        }
        const mergedContent = customMerge(dataFiles[0], dataFiles[1], dataFiles[2]);
        localStorage.setItem('preview_html', mergedContent);

        // Mostrar tabla del cruce
        document.getElementById('cross-table').innerHTML = renderCrossTable(dataFiles[0], dataFiles[1]);

        // Mostrar la vista previa
        outputContainer.innerHTML = mergedContent;
        previewContainer.classList.remove('hidden');
    });

    // Remover el evento submit del formulario para evitar conflictos
    document.getElementById('upload-form').removeEventListener('submit', null);

    // Actualizar el evento del botón de procesar
    document.getElementById('process-cross-btn').addEventListener('click', async (e) => {
        e.preventDefault();
        
        if (!dataFiles[0] || !dataFiles[1]) {
            showToast('❌ Debes cargar los archivos necesarios', 'error');
            return;
        }

        try {
            // Validar datos antes de procesar
            if (!debugMerge(dataFiles[0], dataFiles[1])) {
                showToast('❌ Error en la validación de archivos', 'error');
                return;
            }

            const crossTableHtml = renderCrossTable(dataFiles[0], dataFiles[1]);
            if (crossTableHtml) {
                document.getElementById('cross-table').innerHTML = crossTableHtml;
                document.getElementById('preview-container').classList.remove('hidden');
                showToast('✅ Cruce procesado exitosamente', 'success');
            }
        } catch (error) {
            console.error('Error al procesar el cruce:', error);
            showToast('❌ Error al procesar el cruce', 'error');
        }
    });

    // Función para procesar y generar el archivo CSV actualizado
    function generateUpdatedExport(data1, data2) {
        console.log('🔄 Iniciando actualización de productos...');
        
        // Asegurar que tenemos los encabezados correctos del template
        const templateHeaders = [
            'Handle', 'Title', 'Body (HTML)', 'Vendor', 'Product Category', 'Type', 'Tags', 
            'Published', 'Option1 Name', 'Option1 Value', 'Option2 Name', 'Option2 Value', 
            'Option3 Name', 'Option3 Value', 'Variant SKU', 'Variant Grams', 'Variant Inventory Tracker',
            'Variant Inventory Qty', 'Variant Inventory Policy', 'Variant Fulfillment Service',
            'Variant Price', 'Variant Compare At Price', 'Variant Requires Shipping', 'Variant Taxable',
            'Variant Barcode', 'Image Src', 'Image Position', 'Image Alt Text', 'Gift Card',
            'SEO Title', 'SEO Description', 'Google Shopping / Google Product Category',
            'Google Shopping / Gender', 'Google Shopping / Age Group', 'Google Shopping / MPN',
            'Google Shopping / Condition', 'Google Shopping / Custom Product', 'Variant Image',
            'Variant Weight Unit', 'Variant Tax Code', 'Cost per item', 'Status'
        ];

        // Crear mapa de índices para los campos que necesitamos actualizar
        const indices = {
            codigo: findHeader(data1[0], 'CODIGO'),
            precio: findHeader(data1[0], 'PRECIO_VENTA'),
            cantidad: findHeader(data1[0], 'CANTIDAD'),
            tipologia: findHeader(data1[0], 'Tipologia'),
            sku: findHeader(data2[0], 'Variant SKU'),
            price: findHeader(data2[0], 'Variant Price'),
            comparePrice: findHeader(data2[0], 'Variant Compare At Price'),
            qty: findHeader(data2[0], 'Variant Inventory Qty')
        };

        // Mantener el mapeo exacto del archivo original
        const rows = [];
        rows.push(templateHeaders);

        // Procesar cada fila manteniendo todos los campos originales
        for (let i = 1; i < data2.length; i++) {
            const originalRow = data2[i];
            const newRow = new Array(templateHeaders.length).fill(''); // Inicializar con valores vacíos

            // Copiar todos los valores originales
            templateHeaders.forEach((header, index) => {
                const originalIndex = data2[0].indexOf(header);
                if (originalIndex !== -1) {
                    newRow[index] = originalRow[originalIndex] || '';
                }
            });

            // Actualizar solo los campos necesarios
            const sku = clean(originalRow[indices.sku]);
            const match = data1.slice(1).find(row1 => clean(row1[indices.codigo]) === sku);

            if (match) {
                const precioBase = match[indices.precio];
                const tipologia = match[indices.tipologia];
                const precios = calcularPrecios(precioBase, tipologia);

                // Actualizar precio y cantidad manteniendo el formato original
                const priceIndex = templateHeaders.indexOf('Variant Price');
                const comparePriceIndex = templateHeaders.indexOf('Variant Compare At Price');
                const qtyIndex = templateHeaders.indexOf('Variant Inventory Qty');

                newRow[priceIndex] = precios.price;
                newRow[comparePriceIndex] = precios.comparePrice;
                newRow[qtyIndex] = match[indices.cantidad] || '0';
            }

            rows.push(newRow);
        }

        // Convertir a CSV manteniendo el formato exacto
        return rows.map(row => row.join(',')).join('\n');
    }

    // Actualizar el evento de descarga
    downloadButton.addEventListener('click', () => {
        if (!dataFiles[0] || !dataFiles[1]) {
            alert('No hay datos para procesar');
            return;
        }

        try {
            const updatedData = generateUpdatedExport(dataFiles[0], dataFiles[1]);
            const csvContent = '\ufeff' + updatedData; // Agregar BOM para UTF-8
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'products_export_actualizado.csv';
            a.click();
            URL.revokeObjectURL(url);
        } catch (error) {
            console.error('Error al generar el archivo:', error);
            alert('Error al generar el archivo');
        }
    });

    function debugMerge(data1, data2) {
        console.log("🔍 Iniciando depuración del merge...");

        // Validar que los datos existan y tengan encabezados
        if (!data1 || !Array.isArray(data1) || !data1[0]) {
            console.error("❌ Archivo 1 inválido o sin datos");
            return false;
        }
        if (!data2 || !Array.isArray(data2) || !data2[0]) {
            console.error("❌ Archivo 2 inválido o sin datos");
            return false;
        }

        const headers1 = data1[0];
        const headers2 = data2[0];

        // Validar encabezados requeridos
        const requiredHeaders1 = ['CODIGO', 'PRECIO_VENTA', 'CANTIDAD', 'Tipologia'];
        const requiredHeaders2 = ['Variant SKU', 'Variant Barcode'];

        const missingHeaders1 = requiredHeaders1.filter(header => findHeader(headers1, header) === -1);
        const missingHeaders2 = requiredHeaders2.filter(header => findHeader(headers2, header) === -1);

        if (missingHeaders1.length > 0) {
            console.error("❌ Faltan encabezados en archivo 1:", missingHeaders1);
            return false;
        }

        if (missingHeaders2.length > 0) {
            console.error("❌ Faltan encabezados en archivo 2:", missingHeaders2);
            return false;
        }

        return true;
    }

    // Modificar el evento del botón de procesar
    document.getElementById('process-cross-btn').addEventListener('click', async (e) => {
        e.preventDefault();
        
        if (!dataFiles[0] || !dataFiles[1]) {
            showToast('❌ Debes cargar los archivos necesarios', 'error');
            return;
        }

        try {
            // Validar datos antes de procesar
            if (!debugMerge(dataFiles[0], dataFiles[1])) {
                showToast('❌ Error en la validación de archivos', 'error');
                return;
            }

            const crossTableHtml = renderCrossTable(dataFiles[0], dataFiles[1]);
            if (crossTableHtml) {
                document.getElementById('cross-table').innerHTML = crossTableHtml;
                document.getElementById('preview-container').classList.remove('hidden');
                showToast('✅ Cruce procesado exitosamente', 'success');
            }
        } catch (error) {
            console.error('Error al procesar el cruce:', error);
            showToast('❌ Error al procesar el cruce', 'error');
        }
    });

    // Actualizar el evento del botón de procesar cruce para incluir filtros visibles
    document.getElementById('process-cross-btn').addEventListener('click', (e) => {
        e.preventDefault();
        if (!dataFiles[0] || !dataFiles[1]) {
            alert('Debes cargar los archivos antes de procesar el cruce.');
            return;
        }

        const productos = [];
        const headers1 = dataFiles[0][0];
        const headers2 = dataFiles[1][0];

        const indices = {
            codigo: findHeader(headers1, 'CODIGO'),
            precio: findHeader(headers1, 'PRECIO_VENTA'),
            cantidad: findHeader(headers1, 'CANTIDAD'),
            tipologia: findHeader(headers1, 'Tipologia'),
            sku: findHeader(headers2, 'Variant SKU'),
            barcode: findHeader(headers2, 'Variant Barcode'),
            price: findHeader(headers2, 'Variant Price'),
            comparePrice: findHeader(headers2, 'Variant Compare At Price')
        };

        for (let i = 1; i < dataFiles[1].length; i++) {
            const row2 = dataFiles[1][i];
            let sku = clean(row2[indices.sku]);
            if (!sku && indices.barcode !== -1) {
                sku = clean(row2[indices.barcode]);
            }

            const match = dataFiles[0].slice(1).find(row1 => clean(row1[indices.codigo]) === sku);

            if (match) {
                const precioBase = match[indices.precio];
                const tipologia = match[indices.tipologia];
                const precios = calcularPrecios(precioBase, tipologia);

                productos.push({
                    codigo: match[indices.codigo],
                    precioVenta: limpiarPrecio(precioBase),
                    tipologia: tipologia || 'Sin tipo',
                    variantPrice: precios.price,
                    variantComparePrice: precios.comparePrice || '-',
                    sku,
                    stock: match[indices.cantidad]
                });
            }
        }

        // Mostrar tabla completa
        document.getElementById('cross-table').innerHTML = renderFilteredTable(productos, 'all');
        document.getElementById('preview-container').classList.remove('hidden');

        // Actualizar contenedor de filtros
        updateFilterContainer(productos, 'todos');
    });

    // Actualizar el contenedor de filtros con el nuevo botón
    function updateFilterContainer(productos, tablaActual = 'todos') {
        // Limpiar filtros existentes
        const existingFilters = document.getElementById('filter-container');
        if (existingFilters) {
            existingFilters.remove();
        }

        const filterContainer = document.createElement('div');
        filterContainer.id = 'filter-container';
        filterContainer.style.cssText = `
            margin-top: 1rem;
            display: flex;
            justify-content: center;
            gap: 10px;
        `;

        const buttons = [
            { id: 'todos', text: 'Todos', color: '#4A90E2' },
            { id: 'con-descuento', text: 'Con Descuento', color: '#4CAF50' },
            { id: 'sin-descuento', text: 'Sin Descuento', color: '#F44336' },
            { id: 'no-encontrados', text: 'No Encontrados', color: '#FF9800' }
        ];

        filterContainer.innerHTML = buttons.map(btn => `
            <button id="filter-${btn.id}" 
                    style="padding: 10px 20px; 
                           background-color: ${tablaActual === btn.id ? btn.color : '#888'}; 
                           color: white; 
                           border: none; 
                           border-radius: 5px; 
                           cursor: pointer;">
                ${btn.text}
            </button>
        `).join('');

        // Agregar contenedor después de limpiar el anterior
        document.getElementById('preview-container').prepend(filterContainer);

        // Agregar eventos a los botones
        buttons.forEach(btn => {
            document.getElementById(`filter-${btn.id}`).addEventListener('click', () => {
                buttons.forEach(b => {
                    const button = document.getElementById(`filter-${b.id}`);
                    button.style.backgroundColor = btn.id === b.id ? b.color : '#888';
                });

                let html = '';
                if (btn.id === 'no-encontrados') {
                    html = renderNoEncontradosTable(dataFiles[0], dataFiles[1]);
                } else {
                    const filterType = btn.id === 'todos' ? 'all' : 
                                     btn.id === 'con-descuento' ? 'conDescuento' : 'sinDescuento';
                    html = renderFilteredTable(productos, filterType);
                }
                document.getElementById('cross-table').innerHTML = html;
            });
        });
    }

    function ajustarColumnasTemplate(templateData, nuevoExportData) {
        const templateHeaders = templateData[0];
        const nuevoExportHeaders = nuevoExportData[0];

        // Paso 1: Agregar columnas faltantes
        templateHeaders.forEach(header => {
            if (!nuevoExportHeaders.includes(header)) {
                console.log(`Agregando columna faltante: ${header}`);
                nuevoExportHeaders.push(header);
                nuevoExportData.forEach((row, index) => {
                    if (index > 0) row.push(''); // Agregar columna vacía para cada fila
                });
            }
        });

        // Paso 2: Reordenar columnas según el template
        const reorderedData = [templateHeaders];
        nuevoExportData.slice(1).forEach(row => {
            const reorderedRow = templateHeaders.map(header => {
                const index = nuevoExportHeaders.indexOf(header);
                return index !== -1 ? row[index] : ''; // Mantener datos existentes o agregar vacío
            });
            reorderedData.push(reorderedRow);
        });

        return reorderedData;
    }

    // Actualizar el evento de descarga para ajustar columnas según el template
    downloadButton.addEventListener('click', () => {
        if (!dataFiles[0] || !dataFiles[1]) {
            alert('No hay datos para procesar');
            return;
        }

        try {
            const templateData = JSON.parse(localStorage.getItem('template_data')); // Cargar plantilla desde localStorage
            if (!templateData) {
                alert('Documento descargado con exito');
                return;
            }

            const nuevoExportData = generateUpdatedExport(dataFiles[0], dataFiles[1]);
            const adjustedData = ajustarColumnasTemplate(templateData, nuevoExportData);

            console.log('Datos ajustados según el template:', adjustedData.length, 'filas');

            const csvContent = '\ufeff' + adjustedData.map(row =>
                row.map(cell => `"${(cell || '').toString().replace(/"/g, '""')}"`).join(',')
            ).join('\n');

            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'nuevo_products_export_final.csv';
            a.click();
            URL.revokeObjectURL(url);

            console.log('Archivo final descargado exitosamente');
        } catch (error) {
            console.error('Error al ajustar columnas según el template:', error);
            alert('Error al ajustar columnas según el template. Revisa la consola para más detalles.');
        }
    });

    // Agregar manejadores para botones de remover
    document.querySelectorAll('.remove-file').forEach(button => {
        button.addEventListener('click', (e) => {
            const fileId = button.getAttribute('data-for');
            const input = document.getElementById(fileId);
            if (input) {
                input.value = '';
                const index = parseInt(fileId.replace('doc', '')) - 1;
                dataFiles[index] = null;
                localStorage.removeItem(`doc${index+1}`);
                updateFileStatus(fileId, 'pending');
                filesState.removeState(fileId);
                showToast('🗑️ Archivo eliminado', 'warning');
            }
        });
    });

    // Simplificar la función de generación de reporte
    function generarReporteSKUsNoEncontrados(data1, data2) {
        if (hasDownloadedSkus) return 0; // Si ya se descargó, no hacer nada
        
        const indices = {
            codigo: findHeader(data1[0], 'CODIGO'),
            descripcion: findHeader(data1[0], 'DESCRIPCION'),
            precio: findHeader(data1[0], 'PRECIO_VENTA'),
            cantidad: findHeader(data1[0], 'CANTIDAD'),
            variantSku: findHeader(data2[0], 'Variant SKU'),
            barcode: findHeader(data2[0], 'Variant Barcode')
        };

        // Recolectar SKUs de Shopify
        const skusShopify = new Set();
        data2.slice(1).forEach(row => {
            const sku = clean(row[indices.variantSku]);
            if (sku) skusShopify.add(sku);
            const barcode = clean(row[indices.barcode]);
            if (barcode) skusShopify.add(barcode);
        });

        // Encontrar SKUs no encontrados
        const skusNoEncontrados = data1.slice(1)
            .filter(row => {
                const sku = clean(row[indices.codigo]);
                return sku && !skusShopify.has(sku);
            })
            .map(row => ({
                sku: row[indices.codigo],
                descripcion: row[indices.descripcion] || 'Sin descripción',
                precio: formatDisplayPrice(row[indices.precio]),
                cantidad: row[indices.cantidad] || '0'
            }));

        if (skusNoEncontrados.length === 0) return 0;

        // Generar y descargar CSV
        const headers = ['SKU', 'Descripción', 'Precio', 'Cantidad'];
        const csvContent = [
            headers.join(','),
            ...skusNoEncontrados.map(item => 
                [
                    item.sku,
                    `"${(item.descripcion || '').replace(/"/g, '""')}"`,
                    item.precio,
                    item.cantidad
                ].join(',')
            )
        ].join('\n');

        const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `skus_no_encontrados.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        hasDownloadedSkus = true; // Marcar como descargado
        return skusNoEncontrados.length;
    }

    // Actualizar el evento del botón de descarga
    downloadReportButton.addEventListener('click', () => {
        if (!dataFiles[0] || !dataFiles[1]) {
            alert('❌ Debes cargar los archivos necesarios primero');
            return;
        }

        const count = generarReporteSKUsNoEncontrados(dataFiles[0], dataFiles[1]);
        if (count > 0) {
            alert(`✅ Reporte descargado con ${count} SKUs no encontrados`);
        } else {
            alert('No hay SKUs no encontrados para reportar');
        }
    });

    // Resetear la bandera cuando se cargan nuevos archivos
    fileInputs.forEach(input => {
        input.addEventListener('change', () => {
            hasDownloadedSkus = false;
        });
    });

    // Función para manejar la navegación
    function handleNavigation() {
        const hash = window.location.hash || '#cross-section';
        const sections = ['cross-section', 'docs-section'];
        
        sections.forEach(section => {
            const element = document.getElementById(section);
            if (element) {
                if (`#${section}` === hash) {
                    element.classList.add('active');
                } else {
                    element.classList.remove('active');
                }
            }
        });

        // Actualizar navegación activa
        document.querySelectorAll('.nav-links a').forEach(link => {
            if (link.getAttribute('href') === hash) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }

    // Escuchar cambios en el hash
    window.addEventListener('hashchange', handleNavigation);
    
    // Ejecutar al cargar la página
    handleNavigation();

    // Restaurar estados al cargar la página
    Object.keys(fileStates).forEach(fileId => {
        const state = fileStates[fileId];
        if (state.status === 'success') {
            updateFileStatus(fileId, state.status, state.filename);
        }
    });

    // Encabezados exactos del template de Shopify
    const SHOPIFY_HEADERS = [
        'Handle', 'Title', 'Body (HTML)', 'Vendor', 'Product Category', 'Type', 'Tags', 'Published',
        'Option1 Name', 'Option1 Value', 'Option2 Name', 'Option2 Value', 'Option3 Name', 'Option3 Value',
        'Variant SKU', 'Variant Grams', 'Variant Inventory Tracker', 'Variant Inventory Qty',
        'Variant Inventory Policy', 'Variant Fulfillment Service', 'Variant Price',
        'Variant Compare At Price', 'Variant Requires Shipping', 'Variant Taxable', 'Variant Barcode',
        'Image Src', 'Image Position', 'Image Alt Text', 'Gift Card', 'SEO Title', 'SEO Description',
        'Google Shopping / Google Product Category', 'Google Shopping / Gender', 'Google Shopping / Age Group',
        'Google Shopping / MPN', 'Google Shopping / Condition', 'Google Shopping / Custom Product',
        'Variant Image', 'Variant Weight Unit', 'Variant Tax Code', 'Cost per item', 'Status'
    ];

    // Función para cruzar los datos y obtener el array de productos en formato JSON
    function obtenerCruzadoProductos(data1, data2, data3) {
        // Aquí debes implementar tu lógica de cruce real según tus reglas de negocio.
        // Este ejemplo toma data3 como base y rellena con datos de data1/data2 si es necesario.
        const headers = data3[0];
        const productos = [];

        for (let i = 1; i < data3.length; i++) {
            const row = data3[i];
            const producto = {};
            headers.forEach((header, idx) => {
                producto[header] = row[idx] || '';
            });
            // Aquí podrías sobreescribir campos con datos cruzados de data1/data2 si lo necesitas.
            productos.push(producto);
        }
        return productos;
    }

    // Función para exportar el array cruzadoProductos como CSV Shopify
    function exportarParaSubidaShopify(cruzadoProductos) {
        const csvRows = [
            SHOPIFY_HEADERS.map(h => `"${h}"`).join(','),
            ...cruzadoProductos.map(item =>
                SHOPIFY_HEADERS.map(header => {
                    const value = item[header] || '';
                    return `"${value.toString().replace(/"/g, '""')}"`;
                }).join(',')
            )
        ];
        const csvContent = '\ufeff' + csvRows.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'productos_exportados_para_subida.csv';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        if (typeof showToast === 'function') showToast('✅ Archivo CSV exportado correctamente');
    }

    // Ejemplo de integración después del cruce de datos
    function procesarYExportarShopify() {
        if (!dataFiles[0] || !dataFiles[1] || !dataFiles[2]) {
            showToast('❌ Debes cargar los tres archivos primero', 'error');
            return;
        }
        // dataFiles[x] puede ser un objeto {data: [...], fileName: "..."} según tu lógica, ajusta si es necesario:
        const data1 = Array.isArray(dataFiles[0]) ? dataFiles[0] : dataFiles[0].data;
        const data2 = Array.isArray(dataFiles[1]) ? dataFiles[1] : dataFiles[1].data;
        const data3 = Array.isArray(dataFiles[2]) ? dataFiles[2] : dataFiles[2].data;

        const cruzadoProductos = obtenerCruzadoProductos(data1, data2, data3);
        exportarParaSubidaShopify(cruzadoProductos);
    }

    // Puedes llamar a procesarYExportarShopify() desde un botón o evento después del cruce
    // Ejemplo: document.getElementById('download-btn').onclick = procesarYExportarShopify;
});