# Aplicación de Fusión de Documentos

Este proyecto es una Aplicación de Fusión de Documentos que permite a los usuarios subir tres documentos, fusionar sus contenidos y generar un documento final basado en una plantilla especificada. La aplicación proporciona una interfaz fácil de usar para la gestión de documentos y la vista previa del resultado final.

## Estructura del Proyecto

El proyecto consta de los siguientes archivos:

- `public/index.html`: El archivo HTML principal de entrada para la aplicación. Incluye referencias a los archivos CSS y JavaScript y proporciona la estructura para la interfaz de usuario.
  
- `public/style.css`: Contiene los estilos para la aplicación, definiendo el diseño, colores, fuentes y otros aspectos visuales de los elementos HTML.
  
- `public/template.html`: Sirve como la plantilla para el documento final que se generará después de fusionar los tres documentos de entrada. Proporciona una estructura que se llenará con los datos de los documentos fusionados.
  
- `src/script.js`: Contiene el código JavaScript que maneja la lógica para subir los tres documentos, fusionar su contenido y generar el resultado final basado en la plantilla. También incluye la funcionalidad para previsualizar el documento final antes de descargarlo.

## Comenzando

Para configurar y ejecutar la aplicación, sigue estos pasos:

1. **Clona el repositorio**:
   ```
   git clone <url-del-repositorio>
   ```

2. **Navega al directorio del proyecto**:
   ```
   cd document-merge-app
   ```

3. **Abre el archivo `public/index.html` en tu navegador web** para ver la aplicación.

## Uso

1. Sube los tres documentos que deseas fusionar.
2. La aplicación procesará los documentos y fusionará su contenido.
3. Previsualiza el documento final basado en la plantilla proporcionada.
4. Descarga el documento fusionado cuando estés satisfecho con la vista previa.

## Contribuciones

¡Las contribuciones son bienvenidas! No dudes en enviar un pull request o abrir un issue para cualquier mejora o corrección de errores.

## Licencia

Este proyecto está licenciado bajo la Licencia MIT. Consulta el archivo LICENSE para más detalles.